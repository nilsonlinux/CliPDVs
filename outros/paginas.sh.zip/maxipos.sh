#!/bin/bash
clear
firefox http://pdv.mateus/maxipos_backoffice/app && firefox http://www.armateus.com.br/rcm/
./CliPDVs/CliPDVs.sh;
#© 2020 Nilsonlinux
